<script lang="ts">
	import Pagination from '$lib/components/Pagination.svelte';
	import SearchBox from '$lib/components/SearchBox.svelte';
	import type { Product } from '$lib/types';
	import { goto } from '$app/navigation';

	let {
		data
	}: {
		data: {
			items: Product[];
			total: number;
			page: number;
			pageCount: number;
			q: string;
			size: number;
		};
	} = $props();

	let q = $state(data.q);

	function submitSearch(s: string) {
		q = s;
		const p = new URLSearchParams({ q, page: '1' });
		goto(`/products?${p.toString()}`);
	}

	function go(p: number) {
		const params = new URLSearchParams({ q, page: String(p) });
		goto(`/products?${params.toString()}`);
	}

	const columns = [
		{ key: 'name', label: 'Name' },
		{ key: 'price', label: 'Price' },
		{ key: 'stock', label: 'Stock' },
		{ key: 'active', label: 'Active' },
		{ key: 'actions', label: 'Actions' }
	] as const;
</script>

<section class="space-y-4">
	<div class="flex items-center justify-between">
		<h1 class="text-2xl font-semibold">Products</h1>
		<a
			href="/products/new"
			class="rounded-[var(--radius-pill)] bg-[--color-brand-600] px-5 py-2 text-white hover:opacity-90"
		>
			+ New Product
		</a>
	</div>

	<div class="flex items-center justify-between">
		<SearchBox placeholder="Search products..." onSearch={submitSearch} />
		<div class="text-sm opacity-70">Total: {data.total}</div>
	</div>

	<div
		class="overflow-x-auto rounded-[var(--radius-card)] border border-[--glass-border] bg-white/60 backdrop-blur-md dark:bg-white/10"
	>
		<table class="min-w-full text-sm">
			<thead class="bg-white/60 dark:bg-white/10">
				<tr>
					{#each columns as c}
						<th class="px-4 py-2 text-left font-semibold">{c.label}</th>
					{/each}
				</tr>
			</thead>
			<tbody>
				{#each data.items as row}
					<tr class="odd:bg-white/40 dark:odd:bg-white/5">
						<td class="px-4 py-2">{row.name}</td>
						<td class="px-4 py-2">{row.price}</td>
						<td class="px-4 py-2">{row.stock}</td>
						<td class="px-4 py-2">{row.active ? 'Yes' : 'No'}</td>
						<td class="px-4 py-2">
							<a
								href={`/products/${row.id}/edit`}
								class="rounded-[var(--radius-pill)] border px-3 py-1">Edit</a
							>
							<form method="POST" action="?/delete" class="inline">
								<input type="hidden" name="id" value={row.id} />
								<button
									class="ml-2 rounded-[var(--radius-pill)] border px-3 py-1"
									onclick={(e) => {
										if (!(globalThis as any).confirm?.('Delete?')) e.preventDefault();
									}}
								>
									Delete
								</button>
							</form>
						</td>
					</tr>
				{/each}
				{#if data.items.length === 0}
					<tr><td class="px-4 py-6 opacity-60" colspan={columns.length}>No data</td></tr>
				{/if}
			</tbody>
		</table>
	</div>

	<div class="flex justify-end">
		<Pagination page={data.page} pageCount={data.pageCount} onChange={go} />
	</div>
</section>
